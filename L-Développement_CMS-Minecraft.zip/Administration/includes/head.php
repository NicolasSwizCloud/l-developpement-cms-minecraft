<?php
session_start();
 header('Content-type: text/html; charset=utf-8');

    require_once("../includes/bdd.php");

    if (!(isset($_SESSION['id'])))  {

        header('location: /login'); 

    } 

if(isset($_SESSION['id'])) {

   $requser = $bdd->prepare("SELECT * FROM MEMBRES WHERE id = ?");

   $requser->execute(array($_SESSION['id']));

   $userinfo = $requser->fetch();

  $SQL = $bdd -> prepare("SELECT `GRADE` FROM `MEMBRES` WHERE `id` = :id");
  $SQL -> execute(array(':id' => $_SESSION['id']));
  $rank = $SQL -> fetchColumn(0);
  if (!($rank == admin)) {
    header("Location: /");
    exit;
  }
  
}

?>

<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>
    L-Développement - Administration
  </title>
  <!-- Favicon -->
  <link href="/Administration/assets/img/brand/favicon.png" rel="icon" type="image/png">
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  <link href="/Administration/assets/js/plugins/nucleo/css/nucleo.css" rel="stylesheet" />
  <link href="/Administration/assets/js/plugins/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet" />
  <!-- CSS Files -->
  <link href="/Administration/assets/css/argon-dashboard.css?v=1.1.0" rel="stylesheet" />
</head>
