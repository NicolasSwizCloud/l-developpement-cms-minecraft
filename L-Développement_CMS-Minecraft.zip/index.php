<?php

include('./includes/bdd.php');

$titre = $bdd->query('SELECT * FROM tbl_textes WHERE id = 1');
$titre = $titre->fetch();

$bulle1 = $bdd->query('SELECT * FROM tbl_textes WHERE id = 2');
$bulle1 = $bulle1->fetch();

$bulle2 = $bdd->query('SELECT * FROM tbl_textes WHERE id = 3');
$bulle2 = $bulle2->fetch();

$bulle3 = $bdd->query('SELECT * FROM tbl_textes WHERE id = 4');
$bulle3 = $bulle3->fetch();

$bulle4 = $bdd->query('SELECT * FROM tbl_textes WHERE id = 5');
$bulle4 = $bulle4->fetch();

$ip = $bdd->query('SELECT * FROM tbl_textes WHERE id = 6');
$ip = $ip->fetch();


?>

<!DOCTYPE html>
<html lang="fr">
<head>
	<title><?= $titre['title']; ?></title>
	<meta charset="UTF-8">
	<meta name="description" content="TheQuest Gaming Magazine Template">
	<meta name="keywords" content="gaming, html">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	<!-- Favicon -->
	<link href="img/favicon.ico" rel="shortcut icon"/>

	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,300i,400,400i,500,500i,700,700i&display=swap" rel="stylesheet">

	<!-- Stylesheets -->
	<link rel="stylesheet" href="assets/css/bootstrap.min.css"/>
	<link rel="stylesheet" href="assets/css/font-awesome.min.css"/>
	<link rel="stylesheet" href="assets/css/magnific-popup.css"/>
	<link rel="stylesheet" href="assets/css/owl.carousel.min.css"/>
	<link rel="stylesheet" href="assets/css/animate.css"/>
	<link rel="stylesheet" href="assets/css/slicknav.min.css"/>

	<!-- Main Stylesheets -->
	<link rel="stylesheet" href="assets/css/style.css"/>


	[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	[endif]

</head>
<body>

	<!-- Header section -->
	<header class="header-section">
		<a href="index.html" class="site-logo">
			<h5 style="color: #fff;"><?= $titre['title']; ?></h5>
		</a>
		<ul class="main-menu">
			<li><a href="../">Accueil</a></li>
			<li><a href="">Bouton 1</a></li>
			<li><a href="">Bouton 2</a></li>
			<li><a href="">Bouton 3</a></li>
			<li><a href="">Bouton 4</a></li>
			<li><a href="">Bouton 5</a></li>
			<?php if(isset($_SESSION['id'])) { ?>
			<li><a href="/Administration/" style="margin-left: 200px;">Administration</a></li>
		    <?php }else{ ?>
		    <li><a href="/install/login.php" style="margin-left: 200px;">Connexion</a></li>
		    <?php } ?>
		</ul>
	</header>
	<!-- Header section end -->

	<!-- Hero section -->
	<br />

	<br />

	<br />
	
	<section class="hero-section">
		<div class="hero-slider owl-carousel">
			<div class="hero-item set-bg" data-setbg="img/slider/1.jpg">
				<div class="container">
					<div class="row">
						<div class="col-lg-10 offset-lg-1">
							<h2>Enter the Battle</h2>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. </p>
							<a href="#" class="site-btn">Read More</a>
						</div>
					</div>
				</div>
			</div>
			<div class="hero-item set-bg" data-setbg="img/slider/2.jpg">
				<div class="container">
					<div class="row">
						<div class="col-lg-10 offset-lg-1">
							<h2>Enter the Battle</h2>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. </p>
							<a href="#" class="site-btn">Read More</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Hero section end -->

	<!-- Blog section -->
	<section class="blog-section spad">
		<div class="container">
			<div class="row">
				<div class="col-lg-8 blog-posts">
					<div class="blog-post featured-post">
						<img src="img/blog/1.jpg" alt="">
						<h3><?= $titre['title']; ?></h3>
						<p><?= $titre['description']; ?></p>
					</div>
					<div class="row">
						<div class="col-md-6">
							<div class="blog-post">
								<img src="img/blog/2.jpg" alt="">
								<h4><?= $bulle1['title']; ?></h4>
								<p><?= $bulle1['description']; ?></p>
							</div>
						</div>
						<div class="col-md-6">
							<div class="blog-post">
								<img src="img/blog/3.jpg" alt="">
								<h4><?= $bulle2['title']; ?></h4>
								<p><?= $bulle2['description']; ?></p>
							</div>
						</div>
						<div class="col-md-6">
							<div class="blog-post">
								<img src="https://www.stickpng.com/assets/images/580b57fcd9996e24bc43c302.png" alt="" height="261px;">
								<h4><?= $bulle3['title']; ?></h4>
								<p><?= $bulle3['description']; ?></p>
							</div>
						</div>
						<div class="col-md-6">
							<div class="blog-post">
								<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRzbtPtPacbxRA87sAHnvroDmXC2LhwozLJpLLck7GaG7AUfhJdxw&s" alt="" height="261px;">
								<h4><?= $bulle4['title']; ?></h4>
								<p><?= $bulle4['description']; ?></p>
							</div>
						</div>
					</div>
				</div>
				<div class="col-lg-4 sidebar">
					<div class="sb-widget">
						<form class="sb-search">
							<input type="text" placeholder="Recherche...">
						</form>
					</div>
					<div class="sb-widget">
						<div class="latest-news-widget">
					<div class="sb-widget">
						<a href="#" class="add">
							<img src="img/add-2.png" alt="">
						</a>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Blog section end -->

	<!-- Video section -->
	<div class="video-section">
		<div class="container">
			<div class="video-logo">
				<h3 style="color: #fff;">Notre Serveur en vidéo</h3>>
				<p><?= $titre['title']; ?></p>
			</div>
			<div class="video-popup-warp">
				<img src="img/video-bg.jpg" alt="">
				<a href="<?= $video['description']; ?>" class="video-play"><i class="fa fa-play"></i></a>
			</div>
		</div>
	</div>
	<!-- Video section end -->

	<!-- Footer section -->
	<div class="footer-section">
		<div class="container">
			<div class="row">
				<div class="col-lg-3">
					<div class="footer-widget">
						<div class="about-widget">
							<h4 style="color: #fff;"><?= $titre['title']; ?></h4>
							<p><?= $titre['description']; ?></p>
						</div>
					</div>
				</div>
			</div>
			<div class="copyright"><a href=""><p>
  Copyright &copy; 2019 - <?php echo date("Y"); ?> Tous droit réservé <a href="https://l-developpement.fr" target="_blank">L-Développement</a> | Template by <a href="https://colorlib.com" target="_blank">Colorlib</a>
  <!-- Link back to Colorlib & L-Développement can't be removed. Template is licensed under CC BY 3.0. --></p></div>
		</div>
	<!-- Footer section end -->
															
	<!--====== Javascripts & Jquery ======-->
	<script src="assets/frjs/jquery-3.2.1.min.js"></script>
	<script src="assets/frjs/bootstrap.min.js"></script>
	<script src="assets/frjs/jquery.slicknav.js"></script>
	<script src="assets/frjs/owl.carousel.min.js"></script>
	<script src="assets/frjs/circle-progress.min.js"></script>
	<script src="assets/frjs/jquery.magnific-popup.min.js"></script>
	<script src="assets/frjs/main.js"></script>

	</body>
</html>
