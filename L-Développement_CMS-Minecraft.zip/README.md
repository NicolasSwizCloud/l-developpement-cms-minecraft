Hébergeur* Conseillé
 - HolyCloud.fr
 - Internox.net
 - informatique-fr.fr

# Bienvenue dans le guide d'installation du CMS GMod de L-Développement 

## Pour commencer 

Créer une base de données sur votre hébergeur*

Importer le fichier *database.sql*

## Etape N°2

Mettez les ficher fournie dans votre ftp **public_html** ou **httpdocs**

## Etape N°3

Connecter votre base de données pour cela rendez-vous dans **includes/bdd.php**

## Etape N°4

Rendez vous sur la page https://votresite.com/install/register.php 

Et créer vous un compte

## Etape N°5

Supprimer la page **register.php**

## Etape N°6

Rendez vous dans la table MEMBRE de la base de données puis modifier votre grade pas le grade admin

## Dernière étape

Rendez vous sur la page de connexion et connectez-vous 


# Voila Amusez vous bien sur L-Développement CMS Minecraft



# Notre Discord : https://discord.gg/VPg2C9f

# Notre Site Internet : https://web8456.holycloud.fr/