<?php

session_start();

 header('Content-type: text/html; charset=utf-8');



include('../includes/bdd.php');



      if (isset($_SESSION['id'])) {



      header('Location: /Administration');



      exit();



     }


?>

<?php
if(isset($_POST['connexion'])) {





   $mailconnexion = htmlspecialchars($_POST['mailconnexion']);



   $passwordconnexion = htmlspecialchars($_POST['passwordconnexion']);







   if(!empty($mailconnexion) AND !empty($passwordconnexion)) {



      $SQL = $bdd->prepare("SELECT * FROM MEMBRES WHERE MAIL = ?");



      $SQL->execute(array($mailconnexion));



      $user_exist = $SQL->rowCount();



      if($user_exist == 1)



         $userinfo = $SQL->fetch();



            if(password_verify($passwordconnexion, $userinfo['PASSWORD'])){



          $_SESSION['MAIL'] = $userinfo['MAIL'];



          $_SESSION['id'] = $userinfo['id'];







        $error = '<div class="alert alert-success"><p><strong>Bravo ! </strong>Connexion réussie.  Redirection...</p></div><meta http-equiv="REFRESH" content="1;url=/Administration/">';



            }else{

            $error = '<div class="alert alert-danger"><p><strong>Erreur ! </strong>Votre adresse mail ou votre mot de passe est incorrect !</p></div>';

            }



          } else {



      $error = '<div class="alert alert-danger"><p><strong>Erreur ! </strong>Votre adresse mail ou votre mot de passe est incorrect !</p></div>';



          }



    } else {



          $error = '';



   



}





?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>

    <!-- Font Icon -->
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">

    <!-- Main css -->
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <div class="main">

        <h1>CONNEXION</h1>
        <div class="container">
            <div class="sign-up-content">
                <?php if(isset($error)){echo $error;}?>
                <form method="POST" class="signup-form">
                    <h2 class="form-title">NE PAS SUPPRIMER</h2>
                    <div class="form-radio">

                    <a type="radio" name="member_level" value="average" id="average" href="register.php">
                        <label for="average">Inscription</label>
                    </a>
                    </div>

                    <div class="form-textbox">
                        <label for="name">Email</label>
                        <input type="email" name="mailconnexion" id="mailconnexion" />
                    </div>

                    <br />

                    <div class="form-textbox">
                        <label for="email">Mot de passe</label>
                        <input type="password" name="passwordconnexion" id="passwordconnexion" />
                    </div>

                    <br />

                    <div class="form-textbox">
                        <input type="submit" name="connexion" id="connexion" class="submit" value="Connexion" />
                    </div>
                </form>
            </div>
        </div>

    </div>

    <!-- JS -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="js/main.js"></script>
</body><!-- This templates was made by Colorlib (https://colorlib.com) -->
</html>