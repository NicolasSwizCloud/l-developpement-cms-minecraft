<?php


// Je me connecte à la base de données

try
{
	$bdd = new PDO('mysql:host=localhost;dbname=NOM_DE_LA_BDD;charset=utf8', 'NOM_D\'UTILISATEUR', 'MOT_DE_PASSE');
}
catch (Exception $e)
{
        die('Erreur avec MySQL : ' . $e->getMessage());
}
?>